welcome
<?php 
    echo $_GET['id'];