<?php
    require_once "content/header.php";
    $page = "email_template";
    require_once "pages/page-ini.php";
    require_once "content/footer.php";