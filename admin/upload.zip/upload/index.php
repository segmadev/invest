<?php require_once "content/header.php"; 
if($page != ""){
    require_once "pages/page-ini.php";
}
require_once "content/footer.php"; ?>