<?php 
    session_start();
    require_once "inis/ini.php";
    require_once "content/head.php";
    // echo "yes";
    require_once "pages/page-ini.php";
    require_once "content/foot.php";
    require_once "inis/footer-ini.php";
?>