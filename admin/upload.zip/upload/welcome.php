<div id="content"></div>
<script>
    function load_home() {
     document.getElementById("content").innerHTML='<object type="text/html" data="home?id=3" ></object>';
}
load_home();
</script>