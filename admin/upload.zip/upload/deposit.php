<?php
    require_once "content/header.php";
    $page = "deposit";
    require_once "pages/page-ini.php";
    require_once "content/footer.php";