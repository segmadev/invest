<?php 
    session_start();
    require_once "content/head.php";
    require_once "inis/ini.php";
    require_once "pages/page-ini.php";
    require_once "content/foot.php";
    require_once "inis/footer-ini.php";
?>